# WebsiteBlocker
A website blocker script built on python<br>
#Default websites blocked are facebook and youtube. Blocked websites can be changed by editing the script.<br>
#For linux:<br>Add the exucution of the script to crontab at starting of pc.<br>
#For windows:<br>Change the host file path to "C:\Windows\System32\drivers\etc\hosts", save the script as a .pyw extension and add the execution of the script at startup using task schedular.
